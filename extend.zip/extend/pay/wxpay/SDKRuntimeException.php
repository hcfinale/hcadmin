<?php
namespace pay\wxpay;

class  SDKRuntimeException extends \think\Exception {
    public function errorMessage()
    {
        return $this->getMessage();
    }

}

